package com.training;


class NameNotValidException extends Exception
{
     public String validname()
     {
          return ("Name is not Valid..Please ReEnter the Name");
     }
}