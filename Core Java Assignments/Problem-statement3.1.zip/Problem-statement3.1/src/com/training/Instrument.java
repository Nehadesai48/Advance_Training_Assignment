package com.training;



public abstract class Instrument
{

	public void Play() {
		// TODO Auto-generated method stub
		
	}

}
